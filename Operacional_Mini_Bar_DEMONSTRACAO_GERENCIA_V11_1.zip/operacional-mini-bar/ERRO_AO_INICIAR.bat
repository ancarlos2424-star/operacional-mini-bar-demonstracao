@echo off
cd /d "%~dp0"
title Gran Villagio - Diagnostico
color 0C
echo ==============================================
echo GRAN VILLAGIO - ERRO AO INICIAR
 echo ==============================================
echo.
echo O servidor nao respondeu na porta 3000.
echo Veja o arquivo:
echo data\servidor.log
echo.
type "data\servidor.log"
echo.
pause
