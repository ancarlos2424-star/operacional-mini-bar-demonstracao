@echo off
cd /d "%~dp0"
set PORT=3020
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":%PORT%" ^| findstr "LISTENING"') do (
  taskkill /F /PID %%P >nul 2>&1
)
timeout /t 1 /nobreak >nul
start "" wscript.exe "%~dp0abrir_sistema.vbs"
exit /b
