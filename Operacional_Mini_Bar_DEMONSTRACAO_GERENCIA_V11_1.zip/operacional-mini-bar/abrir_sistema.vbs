Set shell = CreateObject("WScript.Shell")
shell.Run "cmd /c cd /d """ & Replace(WScript.ScriptFullName, "abrir_sistema.vbs", "") & """ && node server.js", 0, False
WScript.Sleep 1200
shell.Run "http://127.0.0.1:3020", 1, False
