@echo off
setlocal
cd /d "%~dp0"
title Gran Villagio - Instalacao Final
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js nao foi encontrado.
 echo Instale o Node.js LTS e execute novamente.
 pause
 exit /b 1
)
if not exist "data" mkdir "data"
if not exist "data\servidor.log" type nul > "data\servidor.log"
if not exist "data\database.json" (
 echo O banco local sera criado na primeira inicializacao.
)
set "SHORTCUT=%USERPROFILE%\Desktop\Gran Villagio - Mini Bar.lnk"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell;$s=$ws.CreateShortcut('%SHORTCUT%');$s.TargetPath='wscript.exe';$s.Arguments='"%~dp0abrir_sistema.vbs"';$s.WorkingDirectory='%~dp0';$s.IconLocation='%SystemRoot%\System32\SHELL32.dll,44';$s.Save()"
start "" wscript.exe "%~dp0abrir_sistema.vbs"
echo.
echo INSTALACAO CONCLUIDA.
echo Foi criado o atalho: Gran Villagio - Mini Bar
exit /b 0
