# Operacional Mini Bar — pacote para teste online

Este pacote é uma preparação para um **teste online**, sem substituir a versão de trabalho local.

## Plataforma prevista
Render Web Service (plano gratuito).

## Configuração
- Build: `npm install`
- Start: `npm start`
- A porta é lida automaticamente de `process.env.PORT`.
- O servidor já escuta em `0.0.0.0`.
- A interface usa chamadas relativas `/api/...`, portanto funciona no endereço público do serviço.
- Health check: `/api/version`.

## Atenção aos dados
A versão atual salva os dados em `data/database.json`. No plano gratuito, o armazenamento local do serviço pode ser perdido em reinicializações/redeploys. Portanto, **este pacote é apenas para teste de acesso e funcionamento online**, não é ainda a implantação definitiva dos dados do hotel.

Antes de uso real, será necessário definir um armazenamento persistente para o banco de dados.
